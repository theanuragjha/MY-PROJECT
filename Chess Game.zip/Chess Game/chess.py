import tkinter as tk
from tkinter import messagebox

class ChessGame:
    def __init__(self):
        self.board = [['R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R'],
                      ['P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'],
                      [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '],
                      [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '],
                      [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '],
                      [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '],
                      ['p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'],
                      ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r']]
        self.selected_piece = None
        self.valid_moves = []
        self.turn = 'white'

        self.root = tk.Tk()
        self.root.title('Chess')
        self.canvas = tk.Canvas(self.root, width=640, height=640)
        self.canvas.pack()
        self.draw_board()
        self.draw_pieces()

        self.canvas.bind('<Button-1>', self.handle_click)

    def draw_board(self):
        colors = ['white', 'gray']
        for i in range(8):
            for j in range(8):
                color = colors[(i + j) % 2]
                x0, y0, x1, y1 = j * 80, i * 80, (j + 1) * 80, (i + 1) * 80
                self.canvas.create_rectangle(x0, y0, x1, y1, fill=color)

    def draw_pieces(self):
        self.canvas.delete('pieces')
        for i in range(8):
            for j in range(8):
                piece = self.board[i][j]
                if piece != ' ':
                    x, y = j * 80 + 40, i * 80 + 40
                    self.canvas.create_text(x, y, text=piece, font=('Arial', 36), tags='pieces')
        if self.selected_piece is not None:
            row, col = self.selected_piece
            x0, y0, x1, y1 = col * 80, row * 80, (col + 1) * 80, (row + 1) * 80
            self.canvas.create_rectangle(x0, y0, x1, y1, outline='blue', width=3)

        for move in self.valid_moves:
            row, col = move
            x0, y0, x1, y1 = col * 80, row * 80, (col + 1) * 80, (row + 1) * 80
            self.canvas.create_rectangle(x0, y0, x1, y1, outline='green', width=3)

    def handle_click(self, event):
        col, row = event.x // 80, event.y // 80
        if self.selected_piece is None:
            piece = self.board[row][col]
            if piece != ' ' and (self.turn == 'white' and piece.isupper() or self.turn == 'black' and piece.islower()):
                self.selected_piece = (row, col)
                self.valid_moves = self.get_valid_moves(row, col)
        else:
            if (row, col) in self.valid_moves:
                self.move_piece(self.selected_piece, (row, col))
            self.selected_piece = None
            self.valid_moves = []

    def move_piece(self, start, end):
        start_row, start_col = start
        end_row, end_col = end
        piece = self.board[start_row][start_col]
        if (self.turn == 'white' and piece.islower()) or (self.turn == 'black' and piece.isupper()):
            messagebox.showinfo('Chess', 'Invalid move!')
            return
        self.board[end_row][end_col] = piece
        self.board[start_row][start_col] = ' '
        self.turn = 'black' if self.turn == 'white' else 'white'
        self.draw_pieces()

    def get_valid_moves(self, row, col):
        return [(row + 1, col), (row - 1, col), (row, col + 1), (row, col - 1)]

    def start(self):
        self.root.mainloop()

if __name__ == '__main__':
    game = ChessGame()
    game.start()
